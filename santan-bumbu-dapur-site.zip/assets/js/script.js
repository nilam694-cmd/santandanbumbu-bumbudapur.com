// ── Product Data dengan gambar asli ──
const productImgs = {
  opor: 'assets/images/product-opor.webp',
  rica: 'assets/images/product-rica.webp',
  rendang: 'assets/images/product-rendang.webp',
  gulai: 'assets/images/product-gulai.webp',
  soto: 'assets/images/product-soto.webp',
  tongseng: 'assets/images/product-tongseng.webp',
  rawon: 'assets/images/product-rawon.webp',
  semur: 'assets/images/product-semur.webp',
};

const products = [
  { name: 'Bumbu Opor', price: 'Rp18.000', desc: 'Gurih dan harum, cocok untuk opor ayam & tahu', imgKey: 'opor', badge: 'Best Seller' },
  { name: 'Bumbu Rica-Rica', price: 'Rp15.000', desc: 'Pedas menggigit dengan aroma rempah yang kuat', imgKey: 'rica', badge: 'Terlaris' },
  { name: 'Bumbu Rendang', price: 'Rp22.000', desc: 'Bumbu kering pekat untuk rendang daging yang legit', imgKey: 'rendang', badge: 'Best Seller' },
  { name: 'Bumbu Gulai', price: 'Rp20.000', desc: 'Kuah kuning kaya santan yang hangat dan lezat', imgKey: 'gulai', badge: 'Terlaris' },
  { name: 'Bumbu Soto', price: 'Rp18.000', desc: 'Kaldu bening harum dengan rempah pilihan Nusantara', imgKey: 'soto', badge: 'Terlaris' },
  { name: 'Bumbu Tongseng', price: 'Rp21.000', desc: 'Manis pedas gurih dengan aroma kecap dan rempah', imgKey: 'tongseng', badge: 'Best Seller' },
  { name: 'Bumbu Rawon', price: 'Rp22.000', desc: 'Hitam pekat dari kluwek, ciri khas Jawa Timur', imgKey: 'rawon', badge: 'Best Seller' },
  { name: 'Bumbu Semur', price: 'Rp18.000', desc: 'Manis dan sedap dari kecap manis pilihan terbaik', imgKey: 'semur', badge: 'Terlaris' },
];

const slider = document.getElementById('productSlider');
products.forEach((p, idx) => {
  const card = document.createElement('div');
  card.className = 'product-card';
  card.innerHTML = `
  <div class="product-card-img">
    <img src="${productImgs[p.imgKey]}" alt="${p.name}" loading="lazy">
    <span class="product-badge">${p.badge}</span>
  </div>
  <div class="product-card-body">
    <div class="product-name">${p.name}</div>
    <div class="product-desc">${p.desc}</div>
    <div class="product-rating"><span class="stars">★★★★★</span><span class="rating-num">5.0</span></div>
    <div class="product-footer">
      <span class="product-price">${p.price}</span>
      <button class="btn-cart" onclick="addToCart(this, '${p.name}')">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
        Tambah
      </button>
    </div>
  </div>`;
  slider.appendChild(card);
});

// ── Slider Logic ──
let currentSlide = 0;
const getVisible = () => window.innerWidth < 480 ? 1 : window.innerWidth < 768 ? 2 : window.innerWidth < 1024 ? 3 : 4;
const cardWidth = () => {
  const card = slider.querySelector('.product-card');
  if (!card) return 240;
  return card.offsetWidth + 20;
};
const maxSlide = () => Math.max(0, products.length - getVisible());

function slideProducts(dir) {
  currentSlide = Math.max(0, Math.min(currentSlide + dir, maxSlide()));
  slider.style.transform = `translateX(-${currentSlide * cardWidth()}px)`;
}

let autoSlide = setInterval(() => {
  if (currentSlide >= maxSlide()) currentSlide = -1;
  slideProducts(1);
}, 4000);

// ── Cart ──
let cartCount = 0;
function addToCart(btn, name) {
  cartCount++;
  const badge = document.getElementById('cartBadge');
  badge.textContent = cartCount;
  badge.classList.add('bump');
  setTimeout(() => badge.classList.remove('bump'), 300);
  btn.classList.add('added');
  btn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Ditambah!`;
  setTimeout(() => {
    btn.classList.remove('added');
    btn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg> Tambah`;
  }, 1500);
  showToast(`🛒 ${name} ditambahkan ke keranjang!`);
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2800);
}

// ── Recipe Modal Data ──
const recipes = {
  opor: {
    title: 'Opor Ayam Jawa',
    img: 'assets/images/recipe-opor.webp',
    ingredients: ['1 ekor ayam, potong 8','1 bungkus Bumbu Opor','400ml santan kental','200ml santan encer','3 lembar daun salam','2 batang serai, memarkan','Garam & gula secukupnya','2 sdm minyak goreng'],
    steps: ['Panaskan minyak, tumis bumbu opor hingga harum dan matang sempurna.','Masukkan ayam, aduk rata hingga ayam berubah warna.','Tuangkan santan encer, tambahkan daun salam dan serai. Masak dengan api sedang.','Setelah mendidih, tuangkan santan kental. Aduk perlahan agar santan tidak pecah.','Tambahkan garam dan gula secukupnya. Koreksi rasa sesuai selera.','Masak hingga ayam empuk dan kuah mengental. Sajikan hangat dengan ketupat.']
  },
  rendang: {
    title: 'Rendang Daging Sapi',
    img: 'assets/images/recipe-rendang.webp',
    ingredients: ['500g daging sapi, potong','1 bungkus Bumbu Rendang','200ml santan kental','100ml air','3 lembar daun jeruk','2 batang serai','1 lembar daun kunyit','Garam secukupnya'],
    steps: ['Masukkan daging sapi bersama bumbu rendang ke dalam wajan. Aduk rata.','Tuangkan santan kental dan air, tambahkan daun jeruk, serai, dan daun kunyit.','Masak dengan api sedang-kecil sambil sesekali diaduk agar santan tidak pecah.','Lanjutkan memasak hingga kuah menyusut dan bumbu meresap ke dalam daging.','Kecilkan api, terus masak hingga bumbu mengering dan berwarna coklat gelap.','Rendang siap disajikan dengan nasi putih atau ketupat Lebaran.']
  },
  soto: {
    title: 'Soto Ayam Kampung',
    img: 'assets/images/recipe-soto.webp',
    ingredients: ['1 ekor ayam kampung','1 bungkus Bumbu Soto','1,5 liter air','200g tauge pendek','100g soun, seduh','3 batang daun bawang','Bawang goreng untuk taburan','Jeruk nipis & sambal'],
    steps: ['Rebus ayam kampung dengan air hingga empuk. Angkat dan suwir dagingnya.','Tumis bumbu soto hingga harum, masukkan ke dalam kaldu ayam.','Didihkan kaldu bumbu, tambahkan garam dan koreksi rasa.','Siapkan mangkuk: tata soun dan tauge, tuangkan kuah panas di atasnya.','Tambahkan suwiran ayam, taburan bawang goreng, dan daun bawang.','Sajikan dengan jeruk nipis, sambal, dan kerupuk. Nikmati selagi panas!']
  }
};

function openRecipe(key) {
  const r = recipes[key];
  document.getElementById('modalImg').src = r.img;
  document.getElementById('modalImg').alt = r.title;
  document.getElementById('modalTitle').textContent = r.title;
  const ing = document.getElementById('modalIngredients');
  ing.innerHTML = r.ingredients.map(i => `<div class="modal-ingredient">${i}</div>`).join('');
  const steps = document.getElementById('modalSteps');
  steps.innerHTML = r.steps.map(s => `<li>${s}</li>`).join('');
  document.getElementById('recipeModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeRecipe() {
  document.getElementById('recipeModal').classList.remove('open');
  document.body.style.overflow = '';
}

function closeModal(e) {
  if (e.target === document.getElementById('recipeModal')) closeRecipe();
}

// ── FAQ ──
function toggleFaq(el) {
  const item = el.parentElement;
  const isOpen = item.classList.contains('open');
  document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
  if (!isOpen) item.classList.add('open');
}

// ── Mobile Menu ──
function toggleMobile() {
  const m = document.getElementById('mobileMenu');
  const h = document.getElementById('hamburger');
  m.classList.toggle('open');
  h.classList.toggle('open');
  document.body.style.overflow = m.classList.contains('open') ? 'hidden' : '';
}
function closeMobile() {
  document.getElementById('mobileMenu').classList.remove('open');
  document.getElementById('hamburger').classList.remove('open');
  document.body.style.overflow = '';
}

// ── Navbar scroll shrink ──
window.addEventListener('scroll', () => {
  const navbar = document.querySelector('.navbar');
  if (window.scrollY > 60) navbar.style.padding = '10px 22px';
  else navbar.style.padding = '14px 28px';
});

// ── Active nav on scroll ──
const sections = ['home','about','products','recipes','why','testimonials','faq','contact'];
window.addEventListener('scroll', () => {
  let current = '';
  sections.forEach(id => {
    const el = document.getElementById(id);
    if (el && window.scrollY >= el.offsetTop - 120) current = id;
  });
  document.querySelectorAll('.nav-links a').forEach(a => {
    a.classList.toggle('active', a.getAttribute('href') === '#' + current);
  });
});

// ── ESC to close modal ──
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeRecipe(); closeMobile(); } });
